package middle.service.demo.Security;

public class token {
    public static String bearerToken;
    public static String parts[];
}
